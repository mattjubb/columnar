package io.columnar.core.store;

import io.columnar.core.DataType;
import io.columnar.core.Schema;

/** Factory for creating type-appropriate {@link ColumnStore}s from a {@link Schema} field. */
public final class ColumnStores {

    private ColumnStores() {}

    public static ColumnStore create(Schema.Field field) {
        return create(field.name(), field.type());
    }

    public static ColumnStore create(String name, DataType type) {
        return switch (type) {
            case INT -> new IntColumnStore(name);
            case LONG -> new LongColumnStore(name);
            case FLOAT -> new FloatColumnStore(name);
            case DOUBLE -> new DoubleColumnStore(name);
            case BOOLEAN -> new BooleanColumnStore(name);
            case STRING -> new StringColumnStore(name);
            case INSTANT -> new InstantColumnStore(name);
            case OBJECT -> throw new UnsupportedOperationException(
                    "OBJECT column type not yet implemented");
        };
    }
}
