package io.columnar.core;

import io.columnar.core.store.BooleanColumnStore;
import io.columnar.core.store.ColumnStore;
import io.columnar.core.store.DoubleColumnStore;
import io.columnar.core.store.FloatColumnStore;
import io.columnar.core.store.InstantColumnStore;
import io.columnar.core.store.IntColumnStore;
import io.columnar.core.store.LongColumnStore;
import io.columnar.core.store.StringColumnStore;

import java.time.Instant;
import java.util.List;

/**
 * Cursor over a row currently being built. Bound to one column index at a time.
 *
 * <p>Used by both static-table builders and live-table appenders. Typed
 * setters ({@link #setLong}, {@link #setDouble}, ...) avoid boxing on the hot path.
 *
 * <p>Workflow:
 * <pre>{@code
 * RowAppender row = appender.row();
 * row.setLong(0, 42L);
 * row.setDouble(1, 3.14);
 * row.setString(2, "hello");
 * row.commit();
 * }</pre>
 */
public final class RowAppender {

    private final List<ColumnStore> stores;
    private final boolean[] columnSet;
    private final Runnable onCommit;

    RowAppender(List<ColumnStore> stores, Runnable onCommit) {
        this.stores = stores;
        this.columnSet = new boolean[stores.size()];
        this.onCommit = onCommit;
    }

    private void mark(int col) {
        if (columnSet[col]) {
            throw new IllegalStateException("column " + col + " already set on this row");
        }
        columnSet[col] = true;
    }

    public RowAppender setInt(int col, int value) {
        mark(col);
        ((IntColumnStore) stores.get(col)).appendInt(value);
        return this;
    }

    public RowAppender setLong(int col, long value) {
        mark(col);
        ((LongColumnStore) stores.get(col)).appendLong(value);
        return this;
    }

    public RowAppender setFloat(int col, float value) {
        mark(col);
        ((FloatColumnStore) stores.get(col)).appendFloat(value);
        return this;
    }

    public RowAppender setDouble(int col, double value) {
        mark(col);
        ((DoubleColumnStore) stores.get(col)).appendDouble(value);
        return this;
    }

    public RowAppender setBoolean(int col, boolean value) {
        mark(col);
        ((BooleanColumnStore) stores.get(col)).appendBoolean(value);
        return this;
    }

    public RowAppender setString(int col, String value) {
        mark(col);
        ((StringColumnStore) stores.get(col)).appendString(value);
        return this;
    }

    public RowAppender setInstant(int col, Instant value) {
        mark(col);
        ((InstantColumnStore) stores.get(col)).appendInstant(value);
        return this;
    }

    public RowAppender setEpochNano(int col, long epochNano) {
        mark(col);
        ((InstantColumnStore) stores.get(col)).appendEpochNano(epochNano);
        return this;
    }

    public RowAppender setNull(int col) {
        mark(col);
        stores.get(col).appendNull();
        return this;
    }

    /** Generic boxing setter — for cases where the type is not known at compile time. */
    public RowAppender set(int col, Object value) {
        mark(col);
        stores.get(col).append(value);
        return this;
    }

    /** Commit the row. Any unset columns are filled with null. */
    public void commit() {
        for (int i = 0; i < columnSet.length; i++) {
            if (!columnSet[i]) {
                stores.get(i).appendNull();
            }
        }
        onCommit.run();
    }
}
